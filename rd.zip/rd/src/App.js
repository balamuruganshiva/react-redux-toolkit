import logo from './logo.svg';
import './App.css';
import NavRoute from './components/NavRoute';

function App() {
  return (
    <NavRoute />
  );
}

export default App;
