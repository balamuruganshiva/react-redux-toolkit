import { useEffect, useState } from 'react';
import { addContact } from '../store/feature/contactSlice';
import ChildComp from './childcom';
import { useSelector, useDispatch } from 'react-redux';

const  Contact1 = (props) => {

    const contact = useSelector(state=> state.contact);
    var uName = "Vinodh12";
    const [contactName, setContactname] = useState("Velan");

    const dispatch = useDispatch();
    const alertChild = (test) =>{
        dispatch(addContact('Vinodh'));
    }
    const alertUseState = (name) => {
        setContactname(name);
        props.par();
    }
    return (
        <>
    <div>Contact123{props.data.name}{contact.name}</div>
    <button onClick={()=>alertChild("Test")}>Test</button>
    <button onClick={()=>alertUseState("Gugan")}>Test1</button>
    <div>{contactName}</div>
    <div>{uName}</div>
    </>
    );
}

function Contact(){
    //const contact = useSelector(state=> state.contact);
    useEffect(()=>{
        alert("test");
    }, []);

    const par = () => {
        alert("Prent");
    }
    return (
        <>
    
    </>
    );
}

export default Contact;