import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../store/feature/cartSlider';
import {Button} from 'react-bootstrap';

function ProductList() {
    const productsList = useSelector((state)=>state.products);
    const dispatch = useDispatch();
    const addToCartProducts = (item) =>{
      const cardProduct = {pId:item.pId, pName:item.pName,pUrl: item.pUrl, pPrice:item.pPrice, qty: 1};
      dispatch(addToCart(cardProduct))
    }
    return(<>
    <div>Poduct List<br/><br/>
      {productsList && productsList.map(item=>{
        return (<div class="pcard">
            <div class="pname">{item.pName}</div>
            <div><img src={item.pUrl} /></div>
            <div><b>Qty</b> : {item.pQty}</div>
            <div><b>Price</b> : &#x20b9; {item.pPrice}</div>
            <div><Button onClick={()=>addToCartProducts(item)}>Add To Card</Button></div>
        </div>)
     })}
    </div>
 
    </>);
}

export default ProductList;