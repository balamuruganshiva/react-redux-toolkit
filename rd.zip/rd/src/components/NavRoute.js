
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from './Layout';
import Home from './Home';
import CartList from './CartList';
import Addproduct from './Addproduct';
import ProductList from  './ProductList';
import Payment from "./Payment";
import HookPage from "./HookPage";
import Contact  from "./Contact";

function NavRoute(){
    return (
        <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index path="home"  element={<Home />} />
            <Route  path="addproduct"  element={<Addproduct />} />
            <Route  path="productlist"  element={<ProductList />} />
            <Route  path="cart"  element={<CartList />} />
            <Route  path="payment"  element={<Payment />} />
            <Route  path="hookpage"  element={<HookPage />} />
            <Route path="contact" element={<Contact />} />
          </Route>
        </Routes>
      </BrowserRouter>
    );
}

export default NavRoute;