import React, { useEffect, useState } from "react";
import useFetchData from "../custom-hook/useFetchData";

function HookPage(){
   const [datanew] = useFetchData('https://jsonplaceholder.typicode.com/users');
   //const [data] = useFetchData('https://jsonplaceholder.typicode.com/todos/1');
   //const [db] = useFetchData('http://localhost:8000/users');
   /*
   const fetchData = (str) =>{

    console.log("Execute"+str);
    fetch('https://jsonplaceholder.typicode.com/users').then(response=>response.json()).then(response=> setUser(response));
   }
    useEffect(()=>{
        setCount(1);
        fetchData('new value');
    }, [])*/
    return (<>
            <div>Hook Page</div>
           
            {datanew && datanew.map(item=>{
                return (<div>{item.email}</div>);
            })}
            
            </>
        )

}

export default HookPage;