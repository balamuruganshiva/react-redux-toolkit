import { useSelector, useDispatch } from 'react-redux';
import {Button} from 'react-bootstrap';
import { addToCart } from '../store/feature/cartSlider';
import { useNavigate } from "react-router-dom";
function CartList(){
    const cart = useSelector((state)=>state.cart);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const payment = () =>{
        navigate('/payment'); 
    }
    const addMoreProduct = (item) =>{
       const cardProduct = {pId:item.pId, pName:item.pName,pUrl: item.pUrl, pPrice:item.pPrice, qty: 1};
      dispatch(addToCart(cardProduct))
    }
    return (
    <>
    <h1 class="cart-detail-page">Cart Detail Page</h1>
    <div class="cart-list">
        {cart && cart.cartProducts.map((item, ind)=>{
            return (<div class="cart-list-item">
              <div class="item-count">{ind+1}</div>
              <div class="item-name">{item.pName}</div>
              <div class="item-image"><img src={item.pUrl} /></div>
              <div class="item-qty">{item.qty}</div>
              <div class="item-price">&#x20b9; {item.pPrice}</div>
              <div class="item-tprice"> {item.qty * item.pPrice}</div>
              <div class="add-more-product"><Button variant="primary" onClick={()=>addMoreProduct(item)}>Add Item</Button></div>
            </div>);
        })}
        <div class="cart-right-total">
            <div><b>Total Qty:{cart.tQty}</ b> </div>
            <div><b>Total Price:&#x20b9; {cart.tPrice}</ b> </div>
            <div><Button variant="primary" onClick={()=>payment()}>Make a Payment</Button></div>
        </div>
    </div>
    </>
    )
}

export default CartList;