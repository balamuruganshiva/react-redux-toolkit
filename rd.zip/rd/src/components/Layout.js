
import Menu from './Menu';
const Layout = () => {
  return (
    <Menu /> 
  )
};

export default Layout;