import { useSelector } from 'react-redux';
function Blog() {
    const productsList = useSelector((state)=>state.products);
    console.log(productsList);
    productsList.map(item=>{
        console.log(item.payload);
    })
    return(<>
    <div>Blog

    {productsList.map((item) => (
        <div>
            <div>{item.pId}</div>
            <div>{item.pName}</div>
            <div>{item.pUrl}</div>
            <div>{item.pQty}</div>
        </div>
      ))}
    </div>
 
    </>);
}

export default Blog;