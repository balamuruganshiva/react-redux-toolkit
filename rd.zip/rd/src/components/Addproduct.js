import {Form, Button} from 'react-bootstrap';
import {useState} from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addProducts, updateProduct } from '../store/feature/productSlice';


function Addproduct(){
    const [pName, setPName] = useState('');
    const [pId, setPId] = useState(0);
    const [pUrl, setPUrl] = useState('');
    const [pQty, setPQty] = useState(0);
    const [pPrice, setpPrice] = useState(0);
    const dispatch = useDispatch();
    const productsList = useSelector((state)=>state.products);

    const submit = () => {
      alert(pId);
      if(pId){
        const addProductData = {pName, pUrl, pQty, pId: pId, pPrice};
        dispatch(updateProduct(addProductData));
      }else{
        const addProductData = {pName, pUrl, pQty, pId: productsList.length+1, pPrice};
        dispatch(addProducts(addProductData));
      }
        setPName('');
        setPUrl('');
        setPQty(0);
        setPId(0);
        setpPrice(0);
    }
    const updateProducts = (item) =>{
        setPName(item.pName);
        setPUrl(item.pUrl);
        setPQty(item.pQty);
        setPId(item.pId);
        setpPrice(item.pPrice);
    }
    return (<>
    <div class="add-product">
        <h1>Add Product</h1><br/>
    
    <Form.Control
        type="hidden"
        value={pId}
      /><br/><br/>
    <b>Product Name</b>
    <Form.Control
        type="text"
        placeholder="Enter Product Name"
        value={pName}
        onChange={(e)=>setPName(e.target.value)}
      /><br/><br/>
      <b>Product Url</b>
      <Form.Control
        type="text"
        placeholder="Enter Product Url"
        value={pUrl}
        onChange={(e)=>setPUrl(e.target.value)}
      /><br/><br/>
      <b>Product Qty</b>
      <Form.Control
        type="text"
        placeholder="Enter Product Qty"
        value={pQty}
        onChange={(e)=>setPQty(e.target.value)}
      /><br/><br/>
      <b>Product Price</b>
      <Form.Control
        type="text"
        placeholder="Enter Price"
        value={pPrice}
        onChange={(e)=>setpPrice(e.target.value)}
      /><br/><br/>
      <Button variant="primary" onClick={()=>submit()}>Add Product</Button>
      </div>
     {productsList && productsList.map(item=>{
        return (<div class="pcard">
            <div class="pname">{item.pName}</div>
            <div><img src={item.pUrl} /></div>
            <div>{item.pQty}</div>
            <div>{item.pPrice}</div>
            <div>
            <Button variant="primary" onClick={()=>updateProducts(item)}>Add Product</Button>
              </div>
        </div>)
     })}
    </>);
}

export default Addproduct;