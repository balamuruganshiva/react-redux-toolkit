

function ChildComp (props1) {

    return (<div>Child Page{props1.user.name}</div>)
}

export default ChildComp;


