import { Outlet, Link } from "react-router-dom";
import { useSelector } from 'react-redux';
import {Button} from 'react-bootstrap';
import { useNavigate } from "react-router-dom";


const Menu = () => {
  const cart = useSelector((state)=>state.cart);
  const navigate = useNavigate();

  const navigateToCart = () =>{
    navigate('/cart');
  }
  return (
    <>
    <div class="header"> 
      <div class="header-left">
      <nav>
        <ul class="nav">
          <li class="nav-item">
            <Link to="/home">Home</Link>
          </li >
          <li class="nav-item">
            <Link to="/addproduct">Add Product</Link>
          </li>
          <li class="nav-item">
            <Link to="/productlist">Product List</Link>
          </li>
          <li class="nav-item">
            <Link to="/hookpage">Hook Page</Link>
          </li>
          <li class="nav-item">
            <Link to="/contact">Contact</Link>
          </li>
          
        </ul>
      </nav>
      </div>
      <div class="header-right">
        <div class="qty">
            <b>Total Quanty: {cart.tQty}</b>
        </div>
        <div class="price">
        <b>Total Price: &#x20b9; {cart.tPrice}</b>
        </div>
        <div><Button variant="primary" onClick={()=>navigateToCart()}>Shopping Cart</Button></div>
      </div>
      </div>
      <Outlet />
    </>
  )
};

export default Menu;