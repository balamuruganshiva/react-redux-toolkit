import { useSelector, useDispatch } from 'react-redux';
import {Button} from 'react-bootstrap';
import { payOrder } from '../store/feature/cartSlider';
import { useState } from 'react';

function Payment(){
    const cart = useSelector((state)=>state.cart);
    const [payFlg, setPayflag] = useState(false);
    const dispatch = useDispatch();
    const palceOrder = () =>{
        dispatch(payOrder());
        setPayflag(true);
    }
    return (
    <>
    <h1 class="cart-detail-page">Payment Detail Page</h1>
    {!payFlg && <div class="cart-list" >
        {cart && cart.cartProducts.map((item, ind)=>{
            return (<div class="cart-list-item">
              <div class="item-count">{ind+1}</div>
              <div class="item-name">{item.pName}</div>
              <div class="item-image"><img src={item.pUrl} /></div>
              <div class="item-qty">{item.qty}</div>
              <div class="item-price">&#x20b9; {item.pPrice}</div>
              <div class="item-tprice"> {item.qty * item.pPrice}</div>
            </div>);
        })}
        <div class="cart-right-total">
            <div><b>Total Qty:{cart.tQty}</ b> </div>
            <div><b>Total Price:&#x20b9; {cart.tPrice}</ b> </div>
        </div>
        <div class="payment-container">
        
<div class="form-check">
  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2" />
  <label class="form-check-label" for="exampleRadios2">
    Cash On Delivery
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3" />
  <label class="form-check-label" for="exampleRadios3">
    UPI Payment
  </label>
</div>
            <Button variant="primary" onClick={()=>palceOrder()}>Place Order</Button>
            </div>
    </div>}
    {
      payFlg && <div class="order">Successfully Order!!!</div>
    }
    </>
    )
}

export default  Payment;