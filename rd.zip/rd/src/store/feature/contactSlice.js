import { createSlice} from "@reduxjs/toolkit";

const contactReducer = createSlice({
    name: "contact",
    initialState: {
        name: "Bala"
    },
    reducers: {
        addContact: (state, action)=>{
            state.name = action.payload
        }
    }
});

export const {addContact} = contactReducer.actions;
export default contactReducer.reducer;