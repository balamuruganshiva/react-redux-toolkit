import { createSlice } from '@reduxjs/toolkit'

export const cartReducer = createSlice({
    name: 'cart',
    initialState: {
        tQty: 0,
        tPrice: 0,
        cartProducts:[]
    },
    reducers: {
      addToCart: (state, action) => {
        const cartUpdate = state.cartProducts.filter((item=> item.pId === action.payload.pId));
        if(cartUpdate.length>0){
          state.cartProducts.forEach(item=>{
            item.qty+=action.payload.qty;
          });
        }else {
          state.cartProducts.push(action.payload);
        }  
        state.tQty+=action.payload.qty;
        state.tPrice += (action.payload.qty* action.payload.pPrice);
      },
      payOrder: (state) => {
        state.tQty = 0;
        state.tPrice = 0;
        state.cartProducts = [];
      }
      
    },
  })
  
  // Action creators are generated for each case reducer function
  export const { addToCart, payOrder } = cartReducer.actions;
  export default cartReducer.reducer;
  