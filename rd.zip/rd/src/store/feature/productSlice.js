import { createSlice } from '@reduxjs/toolkit';

/*const initialState = {
  value: [],
}*/

export const productsReducer = createSlice({
    name: 'products',
    initialState: [],
    reducers: {
      addProducts: (state, action) => {
       
        state.push(action.payload);
            },
      updateProduct: (state, action) => {
       
       state.forEach(element => {
        if(element.pId === action.payload.pId){
          element.pName = action.payload.pName;
          element.pQty = action.payload.pQty;
          element.pUrl = action.payload.pUrl;
          element.pPrice = action.payload.pPrice;
        }
       });
      },
      
    },
  })
  
  // Action creators are generated for each case reducer function
  export const { addProducts, updateProduct } = productsReducer.actions
  export default productsReducer.reducer;
  