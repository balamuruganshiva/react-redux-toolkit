import { configureStore } from '@reduxjs/toolkit';
import  productsReducer  from './feature/productSlice';
import  cartReducer  from './feature/cartSlider';
import  contactReducer from './feature/contactSlice';
export const store = configureStore({
  reducer: {
    products: productsReducer,
    cart: cartReducer,
    contact: contactReducer
  },
})