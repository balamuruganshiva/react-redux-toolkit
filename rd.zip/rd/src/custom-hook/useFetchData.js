import { useEffect, useState, useMemo } from "react";

function useFetchData(url) {
  alert("Execute");
  const [data, setData] = useState(null);
  useMemo(()=>{
    fetch(url).then(response=>response.json()).then(response=> setData(response))
    
}, [url]);
return [data];
}

export default useFetchData;